from math import sqrt
from math import floor

#extended Euclid's algorithm to find modular inverse in O(log m) so in linear time
def modular_inverse(a,m):

	m0 = m 
	y = 0
	x = 1
  
	if (m == 1) : 
		return 0
  
	while (a > 1) : 
  
        #quotient 
		q = a // m 
		t = m 
  
        #m is the remainder
        #same as the Euclid's gcd() algorithm 
		m = a % m 
		a = t 
		t = y 
  
        #update x and y accordingly
		y = x - q * y 
		x = t 
  
  
    #make sure x>0 so x is positive 
	if (x < 0) : 
		x = x + m0 
  
	return x 

if __name__ == "__main__":	

	print(modular_inverse(6546542342343242311,1212434445))