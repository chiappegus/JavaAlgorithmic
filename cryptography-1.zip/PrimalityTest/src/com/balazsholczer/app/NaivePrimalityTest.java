package com.balazsholczer.app;

public class NaivePrimalityTest {

	public boolean isPrime(int num) {
		
		//numbers smaller than 2 are not primes
		if(num<=2) return false;
		
		//even numbers are not primes
		if(num%2==0) return false;
		
		int sqrtNum = (int) Math.sqrt(num);
		
		//we start with 3 because nums<=2 are not primes
		//i+=2 we have to increment by 2 because we do not care about even numbers
		//we have to consider all the items up to sqrt(num)
		for(int i=3;i<sqrtNum;i+=2) {
			
			//it means i divides num so num cannot be a prime
			if(num%i==0) 
				return false;
		}
		
		return true;
	}
}
