package com.balazsholczer.app;

public class App {

	public static void main(String[] args) {
		
		NaivePrimalityTest naivePrimalityTest = new NaivePrimalityTest();
		System.out.println(naivePrimalityTest.isPrime(23));
		
	}
}
