package com.balazsholczer.rsa;

import java.math.BigInteger;

public class App {

	public static void main(String[] args) {
		
		RSA rsa = new RSA();
		rsa.generateKeys(1024);

		String originalMessage = "Hey! This is a secret message encrypted with RSA!";
		System.out.println("Encypted message by Alice: "+originalMessage);
		BigInteger cipher = rsa.encryptMessage(originalMessage);
		System.out.println("Cipher text: "+cipher);
		System.out.println("Decrypted message by Bob: "+rsa.decryptMessage(cipher));
		
	}
}
