package com.balazsholczer.modinv;

import java.math.BigInteger;

public class App {

	public static void main(String[] args) {
		
		ModularInverse modularInverse = new ModularInverse();
		
		BigInteger a = new BigInteger("6546542342343242311");
		BigInteger m = new BigInteger("1212434445");
		
		System.out.println(modularInverse.modularInverse(a, m));
		
	}
}
