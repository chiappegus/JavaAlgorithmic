package com.balazsholczer.modinv;

import java.math.BigInteger;

public class ModularInverse {

	//this is the brute-force approach: we check all the values within the range [0,m-1]
	public BigInteger modularInverse(BigInteger a, BigInteger m) {
		
		BigInteger inv = new BigInteger("0");
		
		//within the range [0,m-1]
		while(inv.compareTo(m)<0) {
			
			//we just have to check a*a^-1 mod m == 1 true or false
			if(a.multiply(inv).mod(m).equals(BigInteger.ONE))
				return inv;
			
			//check the next value in a brute-force manner
			inv = inv.add(BigInteger.ONE);
		}		

		System.out.println("There is no modular inverse (a is not a comprime to m)");
		return null;
	}
}
