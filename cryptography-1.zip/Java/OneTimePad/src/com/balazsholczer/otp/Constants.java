package com.balazsholczer.otp;

public class Constants {

	private Constants() {
		
	}
	
	public static final String ALPHABET = " ABCDEFGHIJKLMNOPQRSTUVWXYZ";
}
