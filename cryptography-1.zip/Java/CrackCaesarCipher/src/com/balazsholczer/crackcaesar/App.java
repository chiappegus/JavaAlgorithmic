package com.balazsholczer.crackcaesar;

public class App {

	public static void main(String[] args) {
		
		CaesarCrack caesarCrack = new CaesarCrack();
		caesarCrack.crack("PMGOLGOHKGHUE OPUNGJVUMPKLU PHSG VGZHEGOLGCYV LGP GPUGJPWOLYG OH GPZGIEGZVGJOHUNPUNG OLGVYKLYGVMG OLGSL  LYZGVMG OLGHSWOHIL G OH GUV GHGCVYKGJVASKGILGTHKLGVA ");
		
	}
}
