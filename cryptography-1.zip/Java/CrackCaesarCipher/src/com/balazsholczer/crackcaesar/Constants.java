package com.balazsholczer.crackcaesar;

public class Constants {

	private Constants() {
		
	}
	
	public static final String ALPHABET = " ABCDEFGHIJKLMNOPQRSTUVWXYZ";
}
