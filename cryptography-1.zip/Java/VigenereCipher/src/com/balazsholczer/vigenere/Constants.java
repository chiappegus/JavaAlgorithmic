package com.balazsholczer.vigenere;

public class Constants {

	private Constants() {
		
	}
	
	public static final String ALPHABET = " ABCDEFGHIJKLMNOPQRSTUVWXYZ";
}
