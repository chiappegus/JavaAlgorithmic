package com.balazsholczer.caesar;

public class Constants {

	private Constants() {
		
	}
	
	public static final String ALPHABET = " ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	public static final int KEY = 3;
}
