from math import sqrt
from math import floor

#this function is useful to check whether two numbers are comprime (relative prime) or not
#if gcd(a,b)=1 then a and b are comprime
def gcd(a,b):

	while b!=0:
		a, b = b, a%b
		
	return a

if __name__ == "__main__":	

	print(gcd(6546542342343242311,1212434445))