package com.balazsholczer.quickselect;

public class App {

	public static void main(String[] args) {
		
		
		
		
		
	}
}
