package AddingNumbers;

public class App {

	public static void main(String[] args) {
		
		Algorithm algorithm = new Algorithm();
		System.out.println(algorithm.sumRecursive(5)); 
		
	}
}
