package TowersOfHanoi;

public class App {

	public static void main(String[] args) {
		
		Algorithm algorithm = new Algorithm();
		algorithm.solveHanoiProblem(3, 'A', 'B', 'C');
		
	}
}
