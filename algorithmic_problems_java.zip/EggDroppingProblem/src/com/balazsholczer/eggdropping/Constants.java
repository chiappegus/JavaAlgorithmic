package com.balazsholczer.eggdropping;

public class Constants {

	private Constants() {

	}
	
	public static final int NUM_OF_EGGS = 2;
	public static final int NUM_OF_FLOORS = 100;
	
}
