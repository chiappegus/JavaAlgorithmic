package com.balazsholczer.knighttour;

public class Constants {

	private Constants(){
		
	}
	
	public static final int BOARD_SIZE = 7;
}
